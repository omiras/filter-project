
    const app = Vue.createApp({
        data() {
            return {
                filter: ''
            }
        },
        methods: {
            clickedFilter(item) {
                this.filter = item
            },
            mustShow(item) {
                return item == filter
            }
        },
    })


    app.mount('#store')

